// servers/home/factionRAM.js
async function main(ns) {
  while (true) {
    await ns.share();
  }
}
export {
  main
};
