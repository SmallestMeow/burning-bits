// servers/home/formtest.js
async function main(ns) {
  ns.tprint(ns.formulas.reputation.calculateFavorToRep(148));
}
export {
  main
};
